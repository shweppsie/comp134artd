using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using SeeSharp.Xna.Video;

namespace Example
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class GameEngine : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;

        VideoPlayer videoPlayer;
        Rectangle renderArea;

        // KeyboardStates to capture keyboard input
        KeyboardState keyState = new KeyboardState();
        KeyboardState oldState = new KeyboardState();

        public GameEngine()
        {
            graphics = new GraphicsDeviceManager(this);
#if DEBUG
            graphics.PreferredBackBufferWidth = 800;
            graphics.PreferredBackBufferHeight = 600;
            graphics.IsFullScreen = false;
            
#else
            graphics.PreferredBackBufferWidth = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width;
            graphics.PreferredBackBufferHeight = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height;
            graphics.IsFullScreen = true;
#endif
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("Arial");
            
            videoPlayer = new VideoPlayer(@"Bear.wmv", GraphicsDevice);
            videoPlayer.OnVideoComplete += new EventHandler(videoPlayer_OnVideoComplete);

            // Slow the game speed to match the video speed.
            // Not required, but can give more CPU time to DirectShow.
            // Helps when displaying very high resolution videos.
            this.IsFixedTimeStep = true;
            if (videoPlayer.MillisecondsPerFrame != -1)
                this.TargetElapsedTime = TimeSpan.FromMilliseconds(videoPlayer.MillisecondsPerFrame);

            // Create a Rectangle to scale the video to fit the window
            int nWidth = Window.ClientBounds.Width;
            int nHeight = Window.ClientBounds.Height;
            int oWidth = videoPlayer.VideoWidth;
            int oHeight = videoPlayer.VideoHeight;

            if (oWidth > oHeight)
            {
                double Ratio = (double)((double)(oHeight) / (double)(oWidth));
                double Final = (nWidth) * Ratio;
                nHeight = (int)Final;
            }
            else
            {
                double Ratio = (double)((double)(oWidth) / (double)(oHeight));
                double Final = (nHeight) * Ratio;
                nWidth = (int)Final;
            }

            renderArea = new Rectangle(0, (Window.ClientBounds.Height - nHeight) / 2, nWidth, nHeight);
        }

        void videoPlayer_OnVideoComplete(object sender, EventArgs e)
        {
            // Close the app once the video has finished
            Exit();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // Required to ensure the player is cleaned up properly
            videoPlayer.Dispose();
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Capture Keyboard Input
            keyState = Keyboard.GetState();

            // Close the app if escape is pressed
            if (keyState.IsKeyDown(Keys.Escape))
                this.Exit();

            // Toggle Playing/Paused if P is pressed
            if (keyState.IsKeyDown(Keys.P))
                if (oldState.IsKeyUp(Keys.P))
                {
                    switch (videoPlayer.CurrentState)
                    {
                        case VideoState.Playing:
                            videoPlayer.CurrentState = VideoState.Paused;
                            break;
                        case VideoState.Paused:
                            videoPlayer.CurrentState = VideoState.Playing;
                            break;
                        case VideoState.Stopped:
                            videoPlayer.CurrentState = VideoState.Playing;
                            break;
                    }
                }

            // Stop the video if S is pressed
            if (keyState.IsKeyDown(Keys.S))
                if (oldState.IsKeyUp(Keys.S))
                    videoPlayer.Stop();

            // Rewind the video if R is pressed
            if (keyState.IsKeyDown(Keys.R))
                if (oldState.IsKeyUp(Keys.R))
                    videoPlayer.Rewind();

            // Update the Video Player
            videoPlayer.Update();

            base.Update(gameTime);

            // Store old input for button state comparison
            oldState = keyState;
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            string playerStateText = "Player State: " + videoPlayer.CurrentState.ToString();
            float ySize = font.MeasureString(playerStateText).Y;

            string controlsText = "P - Play/Pause, S - Stop, R - Rewind";
            Vector2 controlsSize = font.MeasureString(controlsText);

            string infoText = "App will exit when video finishes";
            float xSize = font.MeasureString(infoText).X;

            string fpsText = "Frames per Second: " + (videoPlayer.FramesPerSecond == -1 ? "Unknown" : videoPlayer.FramesPerSecond.ToString());
            float fpsWidth = font.MeasureString(fpsText).X;

            // Begin the SpriteBatch. SaveState is required to prevent subsequent videoPlayer updates failing.
            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred, SaveStateMode.SaveState);
            spriteBatch.Draw(videoPlayer.OutputFrame, renderArea, Color.White);
            spriteBatch.DrawString(font, "Time: " + videoPlayer.CurrentPositionAsTimeString + " / " + videoPlayer.DurationAsTimeString, new Vector2(2, 2), Color.White);
            spriteBatch.DrawString(font, playerStateText, new Vector2(2, Window.ClientBounds.Height - ySize - 2), Color.White);
            spriteBatch.DrawString(font, controlsText, new Vector2(Window.ClientBounds.Width - controlsSize.X - 2, Window.ClientBounds.Height - controlsSize.Y - 2), Color.White);
            spriteBatch.DrawString(font, infoText, new Vector2(Window.ClientBounds.Width - xSize - 2, 2), Color.White);
            spriteBatch.DrawString(font, fpsText, new Vector2((Window.ClientBounds.Width - fpsWidth) / 2, 2), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
